package com.filter.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.DirectoryStream.Filter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyFilter1 implements Filter
{
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain fc)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		out.println("<h1>Filter In</h1>");
		fc.doFilter(req,res);
		out.println("<h1>Filter Out</h1>");
	}

	@Override
	public boolean accept(Object entry) throws IOException {
		// TODO Auto-generated method stub
		return false;
	}


	

}
